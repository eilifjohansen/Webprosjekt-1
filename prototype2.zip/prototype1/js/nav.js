
	$(".subjectlist").on("click", function(){
		
		
		
		 $("this ul").toggle();	
		
	});
	
	
	
