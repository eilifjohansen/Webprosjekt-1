Hey, 
here are the sign in passwords:

Login as student:
Username: student
Password: 111

Login as admin:
Username: admin:
Password: 222

Login as teacher:
Username: teacher
Password: 333



Best regard:
Rikhart, Vegard, Vemund and Eilif